
  # Trading Tool Dashboard

  This is a code bundle for Trading Tool Dashboard. The original project is available at https://www.figma.com/design/6CJgwNiysryingAjTs4Qq8/Trading-Tool-Dashboard.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  